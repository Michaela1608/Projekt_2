import { CommonModule } from '@angular/common';
import { CreateFamilienstandComponent } from './create-familienstand.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
    declarations: [CreateFamilienstandComponent],
    exports: [CreateFamilienstandComponent],
    imports: [CommonModule, ReactiveFormsModule, FontAwesomeModule],
})
export class CreateFamilienstandModule {}

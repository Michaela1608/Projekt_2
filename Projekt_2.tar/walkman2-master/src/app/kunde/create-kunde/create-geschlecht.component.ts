import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { faExclamationCircle } from '@fortawesome/free-solid-svg-icons';


@Component({
    selector: 'hs-create-geschlecht',
    templateUrl: './create-geschlecht.component.html',
})
export class CreateGeschlechtComponent implements OnInit {
    @Input()
    readonly form!: FormGroup;

    readonly geschlecht = new FormControl(undefined, Validators.required);

    readonly faExclamationCircle = faExclamationCircle;

    ngOnInit() {
        console.log('CreateGeschlechtComponent.ngOnInit');
        // siehe formControlName innerhalb @Component({templateUrl: ...})
        this.form.addControl('geschlecht', this.geschlecht);
    }
}

import { CommonModule } from '@angular/common';
import { CreateGeburtsdatumComponent } from './create-geburtsdatum.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
    declarations: [CreateGeburtsdatumComponent],
    exports: [CreateGeburtsdatumComponent],
    imports: [CommonModule, ReactiveFormsModule, FontAwesomeModule],
})
export class CreateGeburtsdatumModule {}

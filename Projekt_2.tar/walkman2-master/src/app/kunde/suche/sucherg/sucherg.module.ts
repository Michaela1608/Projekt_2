import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SuchergComponent } from "./sucherg.component";
import { ErrorMessageModule } from "../../../shared/error-message.module";
import { FontAwesomeModule } from "@fortawesome/angular-fontawesome";
import { RouterModule } from "@angular/router";
import { WaitingModule } from "../../../shared/waiting.module";

@NgModule({
  declarations: [SuchergComponent],
  exports: [SuchergComponent],
  imports: [
    CommonModule,
    RouterModule,
    FontAwesomeModule,
    ErrorMessageModule,
    WaitingModule
  ]
})
export class SuchergModule {}

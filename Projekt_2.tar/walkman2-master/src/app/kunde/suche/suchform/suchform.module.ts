import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SuchformComponent } from "./suchform.component";
import { SuchenachnameModule } from "./suchenachname.module";
import { SucheortModule } from "./sucheort.module";
import { SucheinteresseModule } from "./sucheinteresse.module";
import { FontAwesomeModule } from "@fortawesome/angular-fontawesome";
import { FormsModule } from "@angular/forms";

@NgModule({
  declarations: [SuchformComponent],
  exports: [SuchformComponent],
  imports: [
    CommonModule,
    SuchenachnameModule,
    SucheortModule,
    SucheinteresseModule,
    FontAwesomeModule,
    FormsModule
  ]
})
export class SuchformModule {}

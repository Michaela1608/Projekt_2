import { NgModule } from "@angular/core";
import { SuchenachnameComponent } from "./suchenachname.component";
import { FormsModule } from "@angular/forms";

@NgModule({
  declarations: [SuchenachnameComponent],
  exports: [SuchenachnameComponent],
  imports: [FormsModule]
})
export class SuchenachnameModule {}

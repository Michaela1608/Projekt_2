import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { SucheinteresseComponent } from "./sucheinteresse.component";

@NgModule({
  declarations: [SucheinteresseComponent],
  imports: [FormsModule],
  exports: [SucheinteresseComponent]
})
export class SucheinteresseModule {}

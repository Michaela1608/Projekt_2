import { Component, OnInit } from "@angular/core";

@Component({
  selector: "wm-sucheort",
  templateUrl: "./sucheort.component.html",
  styleUrls: ["./sucheort.component.scss"]
})
export class SucheortComponent implements OnInit {
  ort = "";

  constructor() {
    console.log("SucheortComponent.constructor()");
  }

  ngOnInit() {}
}

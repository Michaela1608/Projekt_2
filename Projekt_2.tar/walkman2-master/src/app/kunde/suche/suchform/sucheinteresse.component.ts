import { Component, OnInit } from "@angular/core";

@Component({
  selector: "wm-sucheinteresse",
  templateUrl: "./sucheinteresse.component.html"
})
export class SucheinteresseComponent implements OnInit {
  lesen = false;
  reisen = false;
  sport = false;

  constructor() {
    console.log("SucheinteresseComponent.Constructor()");
  }

  ngOnInit() {}
}

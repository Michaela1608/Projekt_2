import { Component, OnInit, Output, ViewChild } from "@angular/core";
import { Subject } from "rxjs";
import { Suchkriterien } from "../../shared/kunde.service";
import { fadeIn } from "../../../shared";
import { SuchenachnameComponent } from "./suchenachname.component";
import { SucheortComponent } from "./sucheort.component";
import { SucheinteresseComponent } from "./sucheinteresse.component";
import { NotExpr } from "@angular/compiler";
import {
  faInfoCircle,
  faSearch,
  faFile
} from "@fortawesome/free-solid-svg-icons";

@Component({
  selector: "wm-suchform",
  templateUrl: "./suchform.component.html",
  styleUrls: ["./suchform.component.scss"],
  animations: [fadeIn]
})
export class SuchformComponent {
  @Output()
  readonly suchkriterien = new Subject<Suchkriterien>();

  readonly faInfoCircle = faInfoCircle;
  readonly faSearch = faSearch;
  readonly faFile = faFile;

  @ViewChild(SuchenachnameComponent, { static: true })
  private readonly suchenachnameComponent!: SuchenachnameComponent;

  @ViewChild(SucheortComponent, { static: true })
  private readonly sucheortComponent!: SucheortComponent;

  @ViewChild(SucheinteresseComponent, { static: true })
  private readonly sucheinteresseComponent!: SucheinteresseComponent;

  constructor() {
    console.log("SuchformComponent");
  }

  onFind() {
    const { nachname } = this.suchenachnameComponent;
    const { ort } = this.sucheortComponent;
    const { lesen } = this.sucheinteresseComponent;
    const { reisen } = this.sucheinteresseComponent;
    const { sport } = this.sucheinteresseComponent;

    this.suchkriterien.next({
      nachname,
      ort,
      interessen: { lesen, reisen, sport }
    });

    console.log(`SuchformComponent: onFind() - Nachname : ${nachname},
      Ort : ${ort}`);
  }
}

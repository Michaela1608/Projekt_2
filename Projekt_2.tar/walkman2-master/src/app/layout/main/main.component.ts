import { Component, OnInit } from "@angular/core";

@Component({
  selector: "wm-main",
  template: `
    <main>
      <div class="col col-12 mt-3">
        <router-outlet></router-outlet>
      </div>
    </main>
  `
})
export class MainComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}

import { Component, OnDestroy, OnInit } from "@angular/core";
import { AuthService } from "../../auth/auth.service";
import { HOME_PATH } from "../../shared";
import { Router } from "@angular/router";
import { Subscription } from "rxjs";
import { faSignOutAlt } from "@fortawesome/free-solid-svg-icons";

@Component({
  selector: "wm-login-logout",
  templateUrl: "./login-logout.component.html",
  styleUrls: ["./login-logout.component.scss"]
})
export class LoginLogoutComponent implements OnInit, OnDestroy {
  username: string | undefined;
  password: string | undefined;
  notLoggedIn!: boolean;

  readonly faSignOutAlt = faSignOutAlt;

  /** In order to subscribe to login observable */
  private isLoggedInSubscription!: Subscription;

  constructor(
    private readonly authService: AuthService,
    private readonly router: Router
  ) {}

  ngOnInit() {
    /**
     * When this comp is initialised, check if loggedin and set the notLoggedin var accordingly.
     * notLoggedin var is used to determine which ng-template to display in the html part of this comp.
     */
    this.notLoggedIn = !this.authService.isLoggedIn;
    // authService.isLoggedIn sees if there are any cookies from old logins.
    this.isLoggedInSubscription = this.subscribeLogin();
  }

  ngOnDestroy() {
    this.isLoggedInSubscription.unsubscribe();
  }

  // when the form is submitted onLogin() will be called
  onLogin() {
    console.log("LoginLogoutComponent.onLogin()");
    return this.authService.login(this.username, this.password);
  }

  onLogout() {
    console.log("LoginLogoutComponent.onLogout()");
    this.authService.logout();
    return this.router.navigate([HOME_PATH]);
  }

  private subscribeLogin() {
    const next = (event: boolean) => {
      if (this.notLoggedIn && !event) {
        // Noch nicht eingeloggt und ein Login-Event kommt, d.h.
        // es gab einen Login-Versuch, der aber fehlerhaft (= false) war
        // TODO: Anzeige des fehlgeschlagenen Logins

        console.warn("AuthComponent: Falsche Login-Daten", event);
      }
      this.notLoggedIn = !event;
      console.log("AuthComponent.notLoggedIn:", this.notLoggedIn);
    };

    // Funktion als Funktionsargument, d.h. Code als Daten uebergeben
    return this.authService.isLoggedInSubject.subscribe(next);

    /** When subscribing to an observable/ Subject , the input param of .subscribe is
     * next ,err ,complete
     * the input param of next is what the Observable/ Subject pushes/ produces.
     *
     * Here we are subscribing to the Subject 'isLoggedInSubject', and what it pushes/produces
     * is a boolean value. That is value is 'event' here and it is passed to the 'notLoggegin'
     * var of this component. Whenever 'isLoggedInSubject' pushes a value 'notLoggedIn' will be updated.
     */
  }
}

import { Component, OnInit } from "@angular/core";
import {
  faBook,
  faChartBar,
  faChartLine,
  faChartPie,
  faSearch,
  faHeadphones,
  faCheckCircle,
  faExclamationTriangle,
  faUserPlus
} from "@fortawesome/free-solid-svg-icons";
import { AuthService, ROLLE_ADMIN } from "../../auth/auth.service";
import { Subscription } from "rxjs";

@Component({
  selector: "wm-nav",
  templateUrl: "./nav.component.html",
  styleUrls: ["./nav.component.scss"]
})
export class NavComponent implements OnInit {
  isAdmin!: boolean;
  notLoggedIn!: boolean;

  readonly faHeadphones = faHeadphones;
  readonly faBook = faBook;
  readonly faChartBar = faChartBar;
  readonly faChartLine = faChartLine;
  readonly faChartPie = faChartPie;
  readonly faSearch = faSearch;
  readonly faCheckCircle = faCheckCircle;
  readonly faExclamationTriangle = faExclamationTriangle;
  readonly faUserPlus = faUserPlus;

  private isAdminSubscription!: Subscription;

  constructor(private readonly authService: AuthService) {
    console.log("NavComponent.constructor()");
  }

  ngOnInit() {
    this.isAdmin = this.authService.isAdmin;
    this.notLoggedIn = !this.authService.isLoggedIn;

    // beobachten, ob es Informationen zur Rolle "admin" gibt
    this.isAdminSubscription = this.subscribeIsAdmin();
  }

  ngOnDestroy() {
    this.isAdminSubscription.unsubscribe();
  }

  private subscribeIsAdmin() {
    const next = (event: Array<string>) => {
      this.isAdmin = event !== undefined && event.includes(ROLLE_ADMIN);
      this.isAdmin = this.authService.isAdmin;
      console.log("NavComponent.isAdmin:", this.isAdmin);
    };
    return this.authService.rollenSubject.subscribe(next);
  }
}

import { Component } from "@angular/core";

@Component({
  selector: "wm-root",
  templateUrl: "./app.component.html"
})
export class AppComponent {
  title = "walkman2";
}

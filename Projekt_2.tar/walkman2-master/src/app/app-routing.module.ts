import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { HOME_PATH } from "./shared";
import { HomeComponent } from "./home/home.component";

const routes: Routes = [
  {
    path: "",
    redirectTo: HOME_PATH,
    // redirect erfordert pathMatch full
    pathMatch: "full"
  },
  {
    path: HOME_PATH,
    component: HomeComponent
  },
  {
    path: "kunden",
    // Lazy Loading durch dynamische Imports
    // loadChildren statt component wie bei 'home'
    loadChildren: () =>
      import("./kunde/kunde-routing.module").then(mod => mod.KundeRoutingModule)
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}

import { CommonModule } from "@angular/common";
// https://fontawesome.com/how-to-use/on-the-web/using-with/angular
import { FontAwesomeModule } from "@fortawesome/angular-fontawesome";
import { FormsModule } from "@angular/forms";
import { LoginLogoutComponent } from "./login-logout.component";
import { NgModule } from "@angular/core";

@NgModule({
  declarations: [LoginLogoutComponent],
  exports: [LoginLogoutComponent],
  imports: [CommonModule, FormsModule, FontAwesomeModule]
})
export class LoginLogoutModule {}

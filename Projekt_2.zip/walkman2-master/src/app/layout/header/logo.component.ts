import { Component, OnInit } from "@angular/core";

@Component({
  selector: "wm-logo",
  template: `
    <a routerLink="/">
      <img src="/assets/img/wmlogo.png" alt="Logo" height="370" />
    </a>
  `
})
export class LogoComponent implements OnInit {
  constructor() {}
  alt = "Logo";

  ngOnInit() {}
}

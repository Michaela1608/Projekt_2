import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FontAwesomeModule } from "@fortawesome/angular-fontawesome";
import { NavComponent } from "./nav.component";
import { RouterModule } from "@angular/router";
import { LoginLogoutModule } from "./login-logout.module";

@NgModule({
  declarations: [NavComponent],
  exports: [NavComponent],
  imports: [CommonModule, RouterModule, FontAwesomeModule, LoginLogoutModule]
})
export class NavModule {}

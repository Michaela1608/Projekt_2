import { KundeRoutingModule } from "./kunde-routing.module";
import { NgModule } from "@angular/core";
import { SucheModule } from "./suche/suche.module";

@NgModule({
  imports: [SucheModule, KundeRoutingModule]
})
export class KundeModule {}

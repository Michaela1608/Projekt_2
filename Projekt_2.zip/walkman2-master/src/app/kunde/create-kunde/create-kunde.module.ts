import { CommonModule } from "@angular/common";
//import { CreateEmailModule } from './create-email.module';
import { CreateKundeComponent } from "./create-kunde.component";
import { CreateAdresseModule } from "./create-adresse.module";
import { CreateEmailModule } from "./create-email.module";
import { CreateInteressenModule } from "./create-interessen.module";
import { CreateUmsatzModule } from "./create-umsatz.module";
import { CreateGeschlechtModule } from "./create-geschlecht.module";
import { CreateFamilienstandModule } from "./create-familienstand.module";
import { CreateHomepageModule } from "./create-homepage.module";
import { CreateNachnameModule } from "./create-nachname.module";
import { CreateGeburtsdatumModule } from "./create-geburtsdatum.module";
import { CreateNewsletterModule } from "./create-newsletter.module";
import { CreateUsernameModule } from "./create-username.module";
import { CreateKategorieModule } from "./create-kategorie.module";
import { CreatePasswortModule } from "./create-passwort.module";
import { CreatePlzModule } from "./create-plz.module";

import { ErrorMessageModule } from "../../shared/error-message.module";
import { FontAwesomeModule } from "@fortawesome/angular-fontawesome";
import { HttpClientModule } from "@angular/common/http";
import { NgModule } from "@angular/core";
import { ReactiveFormsModule } from "@angular/forms";
import { Title } from "@angular/platform-browser";

// Ein Modul enthaelt logisch zusammengehoerige Funktionalitaet.
// Exportierte Komponenten koennen bei einem importierenden Modul in dessen
// Komponenten innerhalb deren Templates (= HTML-Fragmente) genutzt werden.
// BuchModule ist ein "FeatureModule", das Features fuer Buecher bereitstellt
@NgModule({
  declarations: [CreateKundeComponent],
  exports: [CreateKundeComponent],
  imports: [
    CommonModule,
    HttpClientModule,
    ReactiveFormsModule,
    FontAwesomeModule,
    CreateNachnameModule,
    CreateAdresseModule,
    CreateEmailModule,
    CreateInteressenModule,
    CreateUmsatzModule,
    CreateGeschlechtModule,
    CreateFamilienstandModule,
    CreateHomepageModule,
    CreateKategorieModule,
    CreateGeburtsdatumModule,
    CreateNewsletterModule,
    CreateUsernameModule,
    CreatePasswortModule,
    CreatePlzModule,
    ErrorMessageModule
  ],
  providers: [Title]
})
export class CreateKundeModule {}

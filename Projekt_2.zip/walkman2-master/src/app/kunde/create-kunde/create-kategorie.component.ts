import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
    selector: 'hs-create-kategorie',
    templateUrl: './create-kategorie.component.html',
})
export class CreateKategorieComponent implements OnInit {
    @Input()
    readonly form!: FormGroup;

    readonly kategorie = new FormControl(undefined);

    ngOnInit() {
        console.log('CreateKategorieComponent.ngOnInit');
        // siehe formControlName innerhalb @Component({templateUrl: ...})
        this.form.addControl('kategorie', this.kategorie);
    }
}

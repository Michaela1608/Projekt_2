/* eslint-disable max-lines */

/*
 * Copyright (C) 2015 - present Juergen Zimmermann, Hochschule Karlsruhe
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

const MIN_RATING = 0;
const MAX_RATING = 5;

export enum GeschlechtTyp {
  M = "MAENNLICH",
  W = "WEIBLICH",
  D = "DIVERS"
}

export enum FamilienstandType {
  VH = "VERHEIRATET",
  L = "LEDIG",
  G = "GESCHIEDEN",
  VW = "VERWITWET"
}

export enum InteresseType {
  S = "SPORT",
  L = "LESEN",
  R = "REISEN"
}

/**
 * Gemeinsame Datenfelder unabh&auml;ngig, ob die Buchdaten von einem Server
 * (z.B. RESTful Web Service) oder von einem Formular kommen.
 */
export interface Adresse {
  ort: string;
  plz: string;
}

export interface Umsatz {
  betrag: Int16Array;
  waehrung: string;
}

export interface KundeShared {
  _id?: string;
  nachname: string;
  email: string;
  adresse: Adresse;
}

interface Link {
  href: string;
}

/**
 * Daten vom und zum REST-Server:
 * <ul>
 *  <li> Arrays f&uuml;r mehrere Werte, die in einem Formular als Checkbox
 *       dargestellt werden.
 *  <li> Daten mit Zahlen als Datentyp, die in einem Formular nur als
 *       String handhabbar sind.
 * </ul>
 */
export interface KundeServer extends KundeShared {
  geburtsdatum: Date;
  interessen: Array<InteresseType>;
  kategorie?: number;
  umsatz?: Umsatz;
  familienstand?: FamilienstandType;
  geschlecht: GeschlechtTyp;
  homepage: string;
  newsletter: boolean;
  username: string;
  _links?: {
    self: Link;
    list?: Link;
    add?: Link;
    update?: Link;
    remove?: Link;
  };
}

/**
 * Daten aus einem Formular:
 * <ul>
 *  <li> je 1 Control fuer jede Checkbox und
 *  <li> au&szlig;erdem Strings f&uuml;r Eingabefelder f&uuml;r Zahlen.
 * </ul>
 */
export interface KundeForm extends KundeShared {
  S?: boolean;
  L?: boolean;
  R?: boolean;
}

/**
 * Model als Plain-Old-JavaScript-Object (POJO) fuer die Daten *UND*
 * Functions fuer Abfragen und Aenderungen.
 */
export class Kunde {
  private static readonly SPACE = 2;

  geburtsdatum: Date | undefined;
  interessen: Array<InteresseType>;

  // wird aufgerufen von fromServer() oder von fromForm()
  // eslint-disable-next-line max-params
  private constructor(
    public _id: string | undefined,
    public nachname: string,
    public adresse: Adresse,
    public email: string,
    interessen: Array<InteresseType>,
    public umsatz: Umsatz,
    public geschlecht: GeschlechtTyp,
    public familienstand: FamilienstandType,
    public homepage: string,
    public kategory: number,
    public version: number | undefined,
    geburtsdatum: Date | undefined,
    public newsletter: boolean,
    public username: string
  ) {
    this.geburtsdatum =
      geburtsdatum === undefined ? new Date() : new Date(geburtsdatum);
    this.interessen = interessen === undefined ? [] : interessen;
    console.log("Kunde(): this=", this);
  }

  /**
   * Ein Buch-Objekt mit JSON-Daten erzeugen, die von einem RESTful Web
   * Service kommen.
   * @param buch JSON-Objekt mit Daten vom RESTful Web Server
   * @return Das initialisierte Buch-Objekt
   */

  static fromServer(KundeServer: KundeServer, etag?: string) {
    /** Because can only be read from the selflink in the response.
     *  The same thing for version an etag.
     */
    let selfLink: string | undefined;
    const { _links } = KundeServer;
    if (_links !== undefined) {
      const { self } = _links;
      selfLink = self.href;
    }

    let id: string | undefined;
    if (selfLink !== undefined) {
      const lastSlash = selfLink.lastIndexOf("/");
      id = selfLink.substring(lastSlash + 1);
    }

    let version: number | undefined;
    if (etag !== undefined) {
      // Anfuehrungszeichen am Anfang und am Ende entfernen
      const versionStr = etag.substring(1, etag.length - 1);
      version = Number.parseInt(versionStr, 10);
    }

    const kunde = new Kunde(
      id,
      KundeServer.nachname,
      KundeServer.adresse,
      KundeServer.email,
      KundeServer.interessen,
      KundeServer.umsatz,
      KundeServer.geschlecht,
      KundeServer.familienstand,
      KundeServer.homepage,
      KundeServer.kategorie,
      version,
      KundeServer.geburtsdatum,
      KundeServer.newsletter,
      KundeServer.username
    );
    console.log("Kunde.fromServer(): kunde=", kunde);
    return kunde;
  }

  /**
   * Ein Buch-Objekt mit JSON-Daten erzeugen, die von einem Formular kommen.
   * @param buch JSON-Objekt mit Daten vom Formular
   * @return Das initialisierte Buch-Objekt
   */
  /*static fromForm(kundeForm: KundeForm) {
    console.log("Buch.fromForm(): kundeForm=", kundeForm);
    const kunde = new Kunde(kundeForm._id, kundeForm.nachname);
    console.log("Buch.fromForm(): buch=", kunde);
    return kunde;
  }*/

  // Property in TypeScript wie in C#
  // https://www.typescriptlang.org/docs/handbook/classes.html#accessors
  get datumFormatted() {
    // z.B. 7. Mai 2020
    const formatter = new Intl.DateTimeFormat("de", {
      year: "numeric",
      month: "long",
      day: "numeric"
    });
    return this.geburtsdatum === undefined
      ? ""
      : formatter.format(this.geburtsdatum);
  }

  /**
   * Abfrage, ob im Buchtitel der angegebene Teilstring enthalten ist. Dabei
   * wird nicht auf Gross-/Kleinschreibung geachtet.
   * @param titel Zu &uuml;berpr&uuml;fender Teilstring
   * @return true, falls der Teilstring im Buchtitel enthalten ist. Sonst
   *         false.
   */
  containsNachname(nachname: string) {
    return this.nachname === undefined
      ? false
      : this.nachname.toLowerCase().includes(nachname.toLowerCase());
  }

  /* toJSON(): KundeServer {
    const geburtsdatum =
      this.geburtsdatum === undefined ? undefined : this.datum.toISOString();
    console.log(`toJson(): geburtsdatum=${geburtsdatum}`);
    return {
      _id: this._id,
      nachname: this.nachname,
      geburtsdatum: this.geburtsdatum,
      
    };
  } */

  toString() {
    return JSON.stringify(this, null, Kunde.SPACE);
  }

  private resetInteressen() {
    this.interessen = [];
  }

  /*  private addSchlagwort(schlagwort: string) {
    if (this.schlagwoerter === undefined) {
      this.schlagwoerter = [];
    }
    this.schlagwoerter.push(schlagwort);
  } */
}

import { BASE_URI, KUNDEN_PATH_REST } from "../../shared";
import { Kunde, KundeServer } from "./kunde";
// Bereitgestellt durch HttpClientModule
// HttpClientModule enthaelt nur Services, keine Komponenten
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
  HttpParams
} from "@angular/common/http";
import { filter, map } from "rxjs/operators";
import { DiagrammService } from "../../shared/diagramm.service";
import { Injectable } from "@angular/core";
// https://github.com/ReactiveX/rxjs/blob/master/src/internal/Subject.ts
// https://github.com/ReactiveX/rxjs/blob/master/src/internal/Observable.ts
import { Subject } from "rxjs";

@Injectable({ providedIn: "root" })
export class KundeService {
  // Observables = Event-Streaming mit Promises
  // Subject statt Basisklasse Observable:
  // in find() und findById() wird next() aufgerufen
  /* eslint-disable no-underscore-dangle */
  readonly kundenSubject = new Subject<Array<Kunde>>();
  readonly kundeSubject = new Subject<Kunde>();
  readonly errorSubject = new Subject<string | number>();

  private readonly baseUriKunden!: string;

  private _kunde!: Kunde;

  //FIXME - authentification
  // headers = new HttpHeaders().set("Authorization", "Basic YWRtaW46cA");

  constructor(private readonly httpClient: HttpClient) {
    this.baseUriKunden = `${BASE_URI}/${KUNDEN_PATH_REST}`;
    console.log(
      `KundeService.constructor(): baseUriKunden=${this.baseUriKunden}`
    );
  }

  set kunde(kunde: Kunde) {
    console.log("KundeService.set kunde()", kunde);
    this._kunde = kunde;
  }

  find(suchkriterien: Suchkriterien) {
    console.log("KundeService.find(): suchkriterien=", suchkriterien);
    const params = this.suchkriterienToHttpParams(suchkriterien);
    const uri = this.baseUriKunden;

    console.log(`KundeService.find(): uri=/rest/`);

    const errorFn = (err: HttpErrorResponse) => {
      if (err.error instanceof ProgressEvent) {
        console.error("Client-seitiger oder Netzwerkfehler", err.error);
        this.errorSubject.next(-1);
        return;
      }

      const { status } = err;
      console.log(
        `KundeService.find(): errorFn(): status=${status}, ` + "Response-Body=",
        err.error
      );
      this.errorSubject.next(status);
    };

    return this.httpClient
      .get<Array<KundeServer>>("/rest/", { params })
      .pipe(
        // Pipeable operators
        // http://reactivex.io/documentation/operators.html
        map(jsonArray =>
          jsonArray.map(jsonObjekt => Kunde.fromServer(jsonObjekt))
        )
      )
      .subscribe(kunden => this.kundenSubject.next(kunden), errorFn);
  }

  remove(
    kunde: Kunde,
    successFn: (() => void) | undefined,
    errorFn: (status: number) => void
  ) {
    console.log("kundeService.remove(): kunde=", kunde);
    const uri = `/rest/${kunde._id}`;

    const errorFnDelete = (err: HttpErrorResponse) => {
      if (err.error instanceof Error) {
        console.error("Client-seitiger oder Netzwerkfehler", err.error.message);
      } else if (errorFn === undefined) {
        console.error("errorFnPut", err);
      } else {
        errorFn(err.status);
      }
    };
    console.log("DELETE uri: ", uri);

    return this.httpClient.delete(uri).subscribe(successFn, errorFnDelete);
  }

  private suchkriterienToHttpParams(suchkriterien: Suchkriterien): HttpParams {
    console.log(
      "KundeService.suchkriterienToHttpParams(): suchkriterien=",
      suchkriterien
    );
    let httpParams = new HttpParams();

    const { nachname, ort, interessen } = suchkriterien;
    const { lesen, reisen, sport } = interessen;

    if (nachname !== "") {
      httpParams = httpParams.set("nachname", nachname);
    }
    if (ort !== "") {
      httpParams = httpParams.set("ort", ort);
    }
    if (lesen === true) {
      httpParams = httpParams.set("interessen", "L");
    }

    if (reisen === true) {
      httpParams = httpParams.set("interessen", "R");
    }
    if (sport === true) {
      httpParams = httpParams.set("interessen", "S");
    }

    console.log("Kundeservice.suchkriterienToHttpParams(): ", httpParams);
    return httpParams;
  }
}

export interface Suchkriterien {
  nachname: string;
  ort: string;
  interessen: { lesen: boolean; reisen: boolean; sport: boolean };
}

import { Component, OnInit } from "@angular/core";

@Component({
  selector: "wm-suchenachname",
  templateUrl: "./suchenachname.component.html"
})
export class SuchenachnameComponent implements OnInit {
  nachname = "";

  constructor() {
    console.log("SuchenachnameComponent.constructor()");
  }

  ngOnInit() {}
}

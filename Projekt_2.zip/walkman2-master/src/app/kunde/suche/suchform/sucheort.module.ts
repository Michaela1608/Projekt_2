import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SucheortComponent } from "./sucheort.component";
import { FormsModule } from "@angular/forms";

@NgModule({
  declarations: [SucheortComponent],
  exports: [SucheortComponent],
  imports: [CommonModule, FormsModule]
})
export class SucheortModule {}

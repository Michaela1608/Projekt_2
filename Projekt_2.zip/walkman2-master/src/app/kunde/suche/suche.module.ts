import { NgModule } from "@angular/core";
import { SucheComponent } from "./suche.component";
import { SuchergModule } from "./sucherg/Sucherg.module";
import { SuchformModule } from "./suchform/Suchform.module";
import { Title } from "@angular/platform-browser";

@NgModule({
  declarations: [SucheComponent],
  exports: [SucheComponent],
  imports: [SuchformModule, SuchergModule]
})
export class SucheModule {}

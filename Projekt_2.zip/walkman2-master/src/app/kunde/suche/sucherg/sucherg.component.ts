import { Component, OnInit, Input, OnChanges, OnDestroy } from "@angular/core";
import { KundeService, Suchkriterien } from "../../shared/kunde.service";
import {
  faFolderOpen,
  faInfoCircle,
  faSearchPlus,
  faTrash,
  faCheckCircle,
  faTimesCircle,
  faAddressCard
} from "@fortawesome/free-solid-svg-icons";
import { Kunde } from "../../shared/kunde";
import { HttpStatus, easeIn, easeOut } from "../../../shared";
import { Subscription } from "rxjs";
import { ActivatedRoute, Router } from "@angular/router";
import { AuthService } from "../../../auth/auth.service";

@Component({
  selector: "wm-sucherg",
  templateUrl: "./sucherg.component.html",
  styleUrls: ["./sucherg.component.scss"],
  animations: [easeIn, easeOut]
})
export class SuchergComponent implements OnInit, OnChanges, OnDestroy {
  @Input()
  suchkriterien: Suchkriterien | undefined;

  readonly faFolderOpen = faFolderOpen;
  readonly faInfoCircle = faInfoCircle;
  readonly faSearchPlus = faSearchPlus;
  readonly faTrash = faTrash;
  readonly faCheckCircle = faCheckCircle;
  readonly faTimesCircle = faTimesCircle;
  readonly faAddressCard = faAddressCard;

  waiting = false;

  kunden: Array<Kunde> = [];
  errorMsg: string | undefined;
  isAdmin!: boolean;

  private kundenSubscription!: Subscription;
  private errorSubscription!: Subscription;
  private removeDescription: Subscription | undefined;

  constructor(
    private readonly kundeservice: KundeService,
    private readonly authService: AuthService,
    private readonly router: Router,
    private readonly route: ActivatedRoute
  ) {
    console.log("SuchergComponent.constuctor()");
  }

  ngOnInit() {
    this.kundenSubscription = this.subscribeKunden();
    this.errorSubscription = this.subscribeError();
    this.isAdmin = this.authService.isAdmin;
  }

  ngOnChanges() {
    console.log(
      `SuchergComponent -> kundeservice.find() mit suchkriterien: ${this.suchkriterien}`
    );

    if (this.suchkriterien === undefined) {
      console.log("SuchergComponent - ngOnChanges - suchkrit undefined");
      return;
    }

    this.waiting = true;
    this.kundeservice.find(this.suchkriterien);
    // this.waiting = true;
    // this.buchService.find(this.suchkriterien);
    //console.log('SuchergComponent: ngOnChanges() - Suchkrit = ',this.suchkriterien);
  }

  ngOnDestroy() {
    this.kundenSubscription.unsubscribe();
    this.errorSubscription.unsubscribe();

    if (this.removeDescription !== undefined) {
      this.removeDescription.unsubscribe();
    }
  }

  onRemove(kunde: Kunde) {
    console.log("delete id:"+kunde._id);
    this.kunden = this.kunden.filter( (k: Kunde) => k._id !== kunde._id);

    console.log("SuchergComponent.onRemove(): kunde=", kunde);
    const successFn: (() => void) | undefined = undefined;
    const errorFn = (status: number) =>
      console.error(`Fehler beim Loeschen: status=${status}`);
    this.removeDescription = this.kundeservice.remove(
      kunde,
      successFn,
      errorFn
    );
  }

  private subscribeKunden() {
    const next = (kunden: Array<Kunde>) => {
      this.reset();
      this.errorMsg = undefined;

      this.kunden = kunden;
      console.log(
        "SuchergComponent.subscribeKunden: this.kunden=",
        this.kunden
      );
    };

    return this.kundeservice.kundenSubject.subscribe(next);
  }

  private subscribeError() {
    const next = (err: string | number | undefined) => {
      this.reset();
      this.kunden = [];

      console.log("SuchergComponent.subscribeError: err=", err);
      if (err === undefined) {
        this.errorMsg = "Ein Fehler ist aufgetreten.";
        return;
      }

      if (typeof err === "string") {
        this.errorMsg = err;
        return;
      }

      switch (err) {
        case HttpStatus.NOT_FOUND:
          this.errorMsg = "Keine Kunden gefunden.";
          break;
        default:
          this.errorMsg = "Ein Fehler ist aufgetreten.";
          break;
      }
      console.log(`SuchergComponent.errorMsg: ${this.errorMsg}`);
    };

    return this.kundeservice.errorSubject.subscribe(next);
  }

  private reset() {
    console.log("SuchergComponent -> reset()");

    this.suchkriterien = {
      nachname: "",
      ort: "",
      interessen: {
        lesen: false,
        reisen: false,
        sport: false
      }
    };
    this.waiting = false;
  }
}

import { Component, OnInit } from "@angular/core";
import { Suchkriterien } from "../shared/kunde.service";
import { Title } from "@angular/platform-browser";

@Component({
  selector: "wm-suche",
  template: `
    <wm-suchform (suchkriterien)="setSuchkriterien($event)"></wm-suchform>
    <wm-sucherg [suchkriterien]="suchkriterien"></wm-sucherg>
  `,
  styleUrls: ["./suche.component.scss"]
})
export class SucheComponent implements OnInit {
  suchkriterien: Suchkriterien;

  constructor(private readonly titleService: Title) {
    console.log("SucheComponent.constructor()");
  }

  ngOnInit() {
    this.titleService.setTitle("Suche Kunde");
  }

  setSuchkriterien($event: Suchkriterien) {
    console.log("SucheComponent.setSuchkriterien(): suchkriterien=", $event);
    this.suchkriterien = $event;
    console.log("SucheComponent.setSuchkriterien(): done! ");
  }
}
